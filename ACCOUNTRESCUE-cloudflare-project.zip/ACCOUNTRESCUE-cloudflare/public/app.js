const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
let currentRole = "guest";
async function api(path, options = {}) {
  const res = await fetch(path, { credentials: "same-origin", ...options });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function showMessage(el, text, kind = "") { el.textContent = text; el.className = `message ${kind}`; }
function showSection(name) {
  ["auth","customer","owner"].forEach(id => $("#"+id).classList.toggle("hidden", id !== name));
  $("#logoutBtn").classList.toggle("hidden", name === "auth");
}
function formData(form) { return new FormData(form); }
$$(".tab").forEach(tab => tab.addEventListener("click", () => {
  $$(".tab").forEach(t => t.classList.toggle("active", t === tab));
  ["login","register","owner"].forEach(id => $("#"+id+"Form").classList.toggle("hidden", id !== tab.dataset.tab));
  showMessage($("#authMessage"), "");
}));
$("#loginForm").addEventListener("submit", async e => {
  e.preventDefault(); const b = Object.fromEntries(formData(e.target));
  try { await api("/api/auth/login",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(b)}); await boot(); }
  catch(err){showMessage($("#authMessage"),err.message,"error");}
});
$("#registerForm").addEventListener("submit", async e => {
  e.preventDefault(); const b = Object.fromEntries(formData(e.target));
  try { const d=await api("/api/auth/register",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(b)}); showMessage($("#authMessage"),d.message+" You can now log in.","success"); e.target.reset(); document.querySelector('[data-tab="login"]').click(); }
  catch(err){showMessage($("#authMessage"),err.message,"error");}
});
$("#ownerForm").addEventListener("submit", async e => {
  e.preventDefault(); const b=Object.fromEntries(formData(e.target));
  try { await api("/api/auth/owner-login",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(b)}); await boot(); }
  catch(err){showMessage($("#authMessage"),err.message,"error");}
});
$("#logoutBtn").addEventListener("click", async()=>{await api("/api/auth/logout",{method:"POST"});showSection("auth");});
$$("[data-copy]").forEach(b=>b.addEventListener("click",async()=>{await navigator.clipboard.writeText(b.dataset.copy);b.textContent="Copied";setTimeout(()=>b.textContent="Copy",1300);}));
async function submitPayment(form, kind, msgEl) {
  form.addEventListener("submit",async e=>{
    e.preventDefault(); const data=new FormData(form); data.set("kind",kind);
    if(kind==="service") data.set("amount_kobo",String(Math.round(Number(data.get("amount"))*100)));
    try { const result=await api("/api/payments",{method:"POST",body:data}); showMessage(msgEl,result.message,"success");form.reset();await loadCustomer(); }
    catch(err){showMessage(msgEl,err.message,"error");}
  });
}
submitPayment($("#registrationPayment"),"registration",$("#registrationStatus"));
submitPayment($("#servicePayment"),"service",$("#serviceStatus"));
$("#appealForm").addEventListener("submit",async e=>{
  e.preventDefault();try{const d=await api("/api/appeals",{method:"POST",body:formData(e.target)});showMessage($("#appealStatus"),"Your appeal has been sent to the developer for review. Reference: "+d.id,"success");e.target.reset();await loadCustomer();}
  catch(err){showMessage($("#appealStatus"),err.message,"error");}
});
function niceStatus(s){return String(s||"").replaceAll("_"," ");}
async function loadCustomer(){
  const d=await api("/api/my-data");
  $("#customerPhone").textContent="Signed in as "+d.user.phone;
  $("#accessPill").textContent=d.user.access_granted?"Appeal access granted":"Registration approval pending";
  $("#accessPill").className="pill "+(d.user.access_granted?"approved":"pending");
  $("#appealSubmit").disabled=!d.user.access_granted;
  $("#customerHistory").innerHTML=[
    ...d.payments.map(p=>`<div class="history-item"><span>${p.kind} payment · ₦${(p.amount_kobo/100).toLocaleString("en-NG")}</span><b>${niceStatus(p.status)}</b></div>`),
    ...d.appeals.map(a=>`<div class="history-item"><span>Appeal · @${escapeHtml(a.instagram_username)}<br><small>${escapeHtml(a.restriction_type)}</small></span><b>${niceStatus(a.status)}</b></div>`)
  ].join("")||'<p class="muted">No payments or appeals submitted yet.</p>';
}
function escapeHtml(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function ownerAction(path,body){await api(path,{method:"PATCH",headers:{"content-type":"application/json"},body:JSON.stringify(body)});await loadOwner();}
async function loadOwner(){
  const d=await api("/api/owner/overview");
  const pending=d.payments.filter(p=>p.status==="pending").length;
  const open=d.appeals.filter(a=>!["submitted_to_meta","closed"].includes(a.status)).length;
  $("#stats").innerHTML=`<div class="stat"><b>${d.users.length}</b><span>CUSTOMERS</span></div><div class="stat"><b>${pending}</b><span>PENDING PAYMENTS</span></div><div class="stat"><b>${open}</b><span>OPEN APPEALS</span></div>`;
  $("#ownerPayments").innerHTML=`<table><thead><tr><th>CUSTOMER</th><th>TYPE</th><th>AMOUNT</th><th>RECEIPT</th><th>STATUS / ACTION</th></tr></thead><tbody>${d.payments.map(p=>`<tr><td>${escapeHtml(p.phone)}</td><td>${p.kind}</td><td>₦${(p.amount_kobo/100).toLocaleString("en-NG")}</td><td><a target="_blank" href="/api/owner/receipts/${p.id}">View image</a></td><td>${niceStatus(p.status)} ${p.status==="pending"?`<div class="table-actions"><button class="mini" data-payment="${p.id}" data-status="approved">Confirm</button><button class="mini reject" data-payment="${p.id}" data-status="rejected">Reject</button></div>`:""}</td></tr>`).join("")}</tbody></table>`;
  $("#ownerAppeals").innerHTML=`<table><thead><tr><th>CUSTOMER</th><th>INSTAGRAM</th><th>RESTRICTION</th><th>EXPLANATION</th><th>STATUS / ACTION</th></tr></thead><tbody>${d.appeals.map(a=>`<tr><td>${escapeHtml(a.phone)}</td><td>@${escapeHtml(a.instagram_username)}<br>${escapeHtml(a.instagram_email)}</td><td>${escapeHtml(a.restriction_type)}</td><td>${escapeHtml(a.explanation)}</td><td>${niceStatus(a.status)}<div class="table-actions"><button class="mini" data-appeal="${a.id}" data-status="under_review">Review</button><button class="mini" data-appeal="${a.id}" data-status="needs_changes">Needs changes</button><button class="mini" data-appeal="${a.id}" data-status="ready_to_submit">Ready to submit</button><button class="mini" data-appeal="${a.id}" data-status="submitted_to_meta">Mark submitted to Meta</button></div></td></tr>`).join("")}</tbody></table>`;
  $("#ownerUsers").innerHTML=`<table><thead><tr><th>PHONE</th><th>REGISTERED</th><th>APPEAL ACCESS</th></tr></thead><tbody>${d.users.map(u=>`<tr><td>${escapeHtml(u.phone)}</td><td>${escapeHtml(u.created_at)}</td><td>${u.access_granted?"Granted":"Pending registration payment"}</td></tr>`).join("")}</tbody></table>`;
  $$("[data-payment]").forEach(b=>b.addEventListener("click",()=>ownerAction(`/api/owner/payments/${b.dataset.payment}`,{status:b.dataset.status})));
  $$("[data-appeal]").forEach(b=>b.addEventListener("click",async()=>{let note="";if(b.dataset.status==="needs_changes")note=prompt("Tell the customer what needs to be corrected:")||"";await ownerAction(`/api/owner/appeals/${b.dataset.appeal}`,{status:b.dataset.status,admin_note:note});}));
}
async function boot(){
  try{const d=await api("/api/me");currentRole=d.role;if(d.role==="owner"){showSection("owner");await loadOwner();}else if(d.role==="customer"){showSection("customer");await loadCustomer();}else showSection("auth");}
  catch{showSection("auth");}
}
boot();
