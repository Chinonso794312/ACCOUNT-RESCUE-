# ACCOUNTRESCUE — Cloudflare deployment

This is a Cloudflare Workers + Workers Assets + D1 + R2 starter for ACCOUNTRESCUE.

## Included workflows
- Customer registration and login by phone number + password.
- Separate owner login, restricted to `OWNER_PHONE`.
- ₦10,000 registration transfer instructions and receipt upload.
- Separate service-payment receipt stage.
- Owner payment review; approving registration unlocks appeal submission.
- Customer appeal submission and case history.
- Owner appeal review. `ready_to_submit` is blocked until service payment is approved.
- Optional WhatsApp Cloud API image notification to the owner when a receipt is uploaded.
- Appeals are prepared for human review; this app does not auto-submit to Instagram or claim Instagram received an appeal.

## Before launch — required setup

1. Install Node.js LTS and Wrangler:
   ```bash
   npm install -g wrangler
   wrangler login
   ```
2. Create D1:
   ```bash
   wrangler d1 create accountrescue-db
   ```
   Copy the returned database ID into `wrangler.toml` in place of `REPLACE_WITH_D1_DATABASE_ID`.
3. Create the R2 bucket:
   ```bash
   wrangler r2 bucket create accountrescue-receipts
   ```
4. Apply the schema:
   ```bash
   wrangler d1 execute accountrescue-db --file=./schema.sql
   ```
5. Set a strong private owner password (at least 12 characters). Do not put it in source code or commit it:
   ```bash
   npx wrangler secret put OWNER_PASSWORD
   ```
   The owner phone is configured as `09031729085` in `wrangler.toml`.
6. Optional WhatsApp receipt-image notification. You need a WhatsApp Business Platform app and a valid recipient opt-in/template-compatible messaging setup. Set secrets:
   ```bash
   npx wrangler secret put WA_ACCESS_TOKEN
   npx wrangler secret put WA_PHONE_NUMBER_ID
   npx wrangler secret put WA_OWNER_NUMBER
   ```
   Use the international-format recipient number, e.g. country code plus number, without `+` or spaces. If these secrets are absent, receipts remain in the owner dashboard and no WhatsApp message is sent.
7. Configure a service fee. The owner can tell customers the service fee, and they enter the amount when uploading their service receipt. For a production payment flow, consider locking the amount to a server-side setting and adding a verified payment provider.
8. Deploy:
   ```bash
   npx wrangler deploy
   ```
9. In Cloudflare dashboard, open Workers & Pages → accountrescue → Settings → Domains & Routes and add `ACCOUNTRESCUE.com` (and optionally `www.ACCOUNTRESCUE.com`). Ensure DNS is active in the same Cloudflare account.

## Important production hardening
- Add phone verification (SMS OTP) before accepting accounts; this starter currently validates phone format but does not send OTP.
- Add rate limiting / Turnstile to registration and login.
- Configure an approved WhatsApp Business messaging flow and test with your own number before accepting customer receipts.
- The owner password is a Cloudflare secret. If you shared a password in chat, change it and set a new one here.
- Confirm every transfer inside your bank app. An uploaded screenshot is not proof of cleared funds.
- Add a service fee policy, refund policy, privacy notice and support contact before public launch.
- Instagram username/email are collected for case preparation only. Never collect Instagram passwords, OTPs, backup codes, or session cookies.
- Meta/Instagram decides whether to restore accounts. No success rate or restoration outcome is guaranteed.
- `submitted_to_meta` is a manual owner status. It does not send anything to Instagram. The owner must submit through the official Instagram/Meta appeal process and only then mark the case accordingly.

## Files
- `public/` — customer and owner interface
- `src/worker.js` — API, auth, receipt storage, access controls and owner actions
- `schema.sql` — D1 schema
- `wrangler.toml` — Cloudflare Worker, D1 and R2 bindings
