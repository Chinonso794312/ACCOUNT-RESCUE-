const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
  });

const fail = (message, status = 400) => json({ error: message }, status);
const uid = () => crypto.randomUUID();
const enc = new TextEncoder();

function b64(bytes) {
  return btoa(String.fromCharCode(...new Uint8Array(bytes)));
}
function fromB64(s) {
  return Uint8Array.from(atob(s), c => c.charCodeAt(0));
}
async function sha256(value) {
  return b64(await crypto.subtle.digest("SHA-256", enc.encode(value)));
}
async function derivePassword(password, saltB64) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: fromB64(saltB64), iterations: 210000, hash: "SHA-256" },
    key, 256
  );
  return b64(bits);
}
function cookie(request) {
  const raw = request.headers.get("Cookie") || "";
  const match = raw.match(/(?:^|;\s*)ar_session=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : null;
}
function sessionCookie(token, maxAge = 60 * 60 * 24 * 7) {
  return `ar_session=${encodeURIComponent(token)}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${maxAge}`;
}
async function currentUser(request, env) {
  const token = cookie(request);
  if (!token) return null;
  const hash = await sha256(token);
  const row = await env.DB.prepare(
    `SELECT u.id,u.phone,u.access_granted FROM sessions s
     JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?`
  ).bind(hash, Date.now()).first();
  return row || null;
}
async function requireUser(request, env) {
  const user = await currentUser(request, env);
  return user || false;
}
async function isOwner(request, env) {
  const phone = request.headers.get("x-owner-phone");
  // Owner authentication is a separate session cookie issued only after the owner secret check.
  const token = cookie(request);
  if (!token) return false;
  const hash = await sha256(token);
  const row = await env.DB.prepare(
    "SELECT owner_flag FROM admin_sessions WHERE token_hash=? AND expires_at>?"
  ).bind(hash, Date.now()).first();
  return !!row;
}
async function ownerLogin(request, env) {
  const body = await request.json().catch(() => ({}));
  const phone = String(body.phone || "").trim();
  const password = String(body.password || "");
  if (phone !== String(env.OWNER_PHONE || "")) return fail("Owner credentials are incorrect.", 401);
  if (!env.OWNER_PASSWORD || password.length < 12) return fail("Owner login is not configured. Set OWNER_PASSWORD as a Cloudflare secret (at least 12 characters).", 503);
  // Constant-time comparison over equal-length UTF-8 byte arrays.
  const a = enc.encode(password), b = enc.encode(env.OWNER_PASSWORD);
  let diff = a.length ^ b.length;
  for (let i = 0; i < Math.max(a.length, b.length); i++) diff |= (a[i] || 0) ^ (b[i] || 0);
  if (diff !== 0) return fail("Owner credentials are incorrect.", 401);
  const token = b64(crypto.getRandomValues(new Uint8Array(32)));
  await env.DB.prepare("INSERT INTO admin_sessions(token_hash,owner_flag,expires_at) VALUES(?,1,?)")
    .bind(await sha256(token), Date.now() + 7 * 86400000).run();
  return new Response(JSON.stringify({ ok: true, owner: true }), {
    headers: { "content-type": "application/json", "set-cookie": sessionCookie(token) }
  });
}
async function notifyOwnerWithReceipt(env, payment, receiptBytes, contentType) {
  if (!env.WA_ACCESS_TOKEN || !env.WA_PHONE_NUMBER_ID || !env.WA_OWNER_NUMBER) return;
  const form = new FormData();
  form.append("messaging_product", "whatsapp");
  form.append("file", new Blob([receiptBytes], { type: contentType }), "payment-receipt");
  const mediaRes = await fetch(`https://graph.facebook.com/v22.0/${env.WA_PHONE_NUMBER_ID}/media`, {
    method: "POST",
    headers: { Authorization: `Bearer ${env.WA_ACCESS_TOKEN}` },
    body: form
  });
  if (!mediaRes.ok) throw new Error("WhatsApp media upload failed");
  const media = await mediaRes.json();
  const message = {
    messaging_product: "whatsapp",
    to: env.WA_OWNER_NUMBER,
    type: "image",
    image: { id: media.id, caption: `ACCOUNTRESCUE payment receipt\nType: ${payment.kind}\nAmount: ₦${(payment.amount_kobo / 100).toLocaleString("en-NG")}\nPayment ID: ${payment.id}\nPlease verify the transfer in your bank account.` }
  };
  const sendRes = await fetch(`https://graph.facebook.com/v22.0/${env.WA_PHONE_NUMBER_ID}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${env.WA_ACCESS_TOKEN}`, "content-type": "application/json" },
    body: JSON.stringify(message)
  });
  if (!sendRes.ok) throw new Error("WhatsApp notification failed");
}
async function uploadFile(file, env, userId, prefix) {
  if (!(file instanceof File)) throw new Error("Please attach an image.");
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) throw new Error("Use a JPG, PNG or WebP image.");
  if (file.size > 5 * 1024 * 1024) throw new Error("Image must be 5 MB or smaller.");
  const key = `${prefix}/${userId}/${uid()}`;
  const bytes = await file.arrayBuffer();
  await env.RECEIPTS.put(key, bytes, { httpMetadata: { contentType: file.type } });
  return { key, bytes, contentType: file.type };
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith("/api/")) return env.ASSETS.fetch(request);
    if (request.method === "OPTIONS") return new Response(null, { headers: { "access-control-allow-origin": url.origin, "access-control-allow-credentials": "true" } });

    try {
      if (url.pathname === "/api/health" && request.method === "GET") return json({ ok: true, app: "ACCOUNTRESCUE" });

      if (url.pathname === "/api/auth/register" && request.method === "POST") {
        const body = await request.json();
        const phone = String(body.phone || "").replace(/[^\d+]/g, "");
        const password = String(body.password || "");
        if (!/^\+?\d{10,15}$/.test(phone)) return fail("Enter a valid phone number with country code if needed.");
        if (password.length < 10) return fail("Password must contain at least 10 characters.");
        const salt = b64(crypto.getRandomValues(new Uint8Array(16)));
        const hash = await derivePassword(password, salt);
        const id = uid();
        try {
          await env.DB.prepare("INSERT INTO users(id,phone,password_hash,password_salt) VALUES(?,?,?,?)")
            .bind(id, phone, hash, salt).run();
        } catch {
          return fail("That phone number already has an account.", 409);
        }
        return json({ ok: true, message: "Account created. Please log in." }, 201);
      }

      if (url.pathname === "/api/auth/login" && request.method === "POST") {
        const body = await request.json();
        const phone = String(body.phone || "").replace(/[^\d+]/g, "");
        const password = String(body.password || "");
        const user = await env.DB.prepare("SELECT * FROM users WHERE phone=?").bind(phone).first();
        if (!user || await derivePassword(password, user.password_salt) !== user.password_hash) return fail("Phone number or password is incorrect.", 401);
        const token = b64(crypto.getRandomValues(new Uint8Array(32)));
        await env.DB.prepare("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)")
          .bind(await sha256(token), user.id, Date.now() + 7 * 86400000).run();
        return new Response(JSON.stringify({ ok: true }), {
          headers: { "content-type": "application/json", "set-cookie": sessionCookie(token) }
        });
      }

      if (url.pathname === "/api/auth/owner-login" && request.method === "POST") return ownerLogin(request, env);

      if (url.pathname === "/api/auth/logout" && request.method === "POST") {
        const token = cookie(request);
        if (token) {
          const hash = await sha256(token);
          await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(hash).run();
          await env.DB.prepare("DELETE FROM admin_sessions WHERE token_hash=?").bind(hash).run();
        }
        return new Response(JSON.stringify({ ok: true }), { headers: { "content-type": "application/json", "set-cookie": sessionCookie("", 0) } });
      }

      if (url.pathname === "/api/me" && request.method === "GET") {
        const user = await currentUser(request, env);
        if (user) return json({ role: "customer", user });
        if (await isOwner(request, env)) return json({ role: "owner", phone: env.OWNER_PHONE });
        return json({ role: "guest" });
      }

      if (url.pathname === "/api/payments" && request.method === "POST") {
        const user = await requireUser(request, env);
        if (!user) return fail("Please log in first.", 401);
        const form = await request.formData();
        const kind = String(form.get("kind") || "");
        if (!["registration", "service"].includes(kind)) return fail("Invalid payment type.");
        if (kind === "service" && !user.access_granted) return fail("Registration payment must be approved first.");
        const amount = kind === "registration" ? Number(env.REGISTRATION_FEE_KOBO || 1000000) : Number(form.get("amount_kobo") || 0);
        if (!Number.isInteger(amount) || amount <= 0) return fail("The service fee has not been configured. Contact support.");
        const upload = await uploadFile(form.get("file"), env, user.id, "receipts");
        const id = uid();
        await env.DB.prepare("INSERT INTO payments(id,user_id,kind,amount_kobo,receipt_key) VALUES(?,?,?,?,?)")
          .bind(id, user.id, kind, amount, upload.key).run();
        try {
          await notifyOwnerWithReceipt(env, { id, kind, amount_kobo: amount }, upload.bytes, upload.contentType);
        } catch (e) {
          // The receipt is safely stored and visible in the owner dashboard even if WhatsApp is not configured.
          console.error("WhatsApp notification error:", e.message);
        }
        return json({ ok: true, id, status: "pending", message: "Receipt submitted. Your payment is awaiting manual verification." }, 201);
      }

      if (url.pathname === "/api/appeals" && request.method === "POST") {
        const user = await requireUser(request, env);
        if (!user) return fail("Please log in first.", 401);
        if (!user.access_granted) return fail("Your registration payment must be approved before submitting an appeal.");
        const form = await request.formData();
        const username = String(form.get("instagram_username") || "").trim();
        const email = String(form.get("instagram_email") || "").trim();
        const restriction = String(form.get("restriction_type") || "").trim();
        const explanation = String(form.get("explanation") || "").trim();
        if (!username || !email.includes("@") || !restriction || explanation.length < 30) return fail("Complete all appeal fields. Your explanation must be at least 30 characters.");
        if (/password|otp|backup code|session cookie/i.test(explanation)) return fail("Do not include passwords, one-time codes, backup codes or session cookies.");
        let evidenceKey = null;
        const file = form.get("file");
        if (file instanceof File && file.size > 0) {
          const upload = await uploadFile(file, env, user.id, "appeal-evidence");
          evidenceKey = upload.key;
        }
        const id = uid();
        await env.DB.prepare(`INSERT INTO appeals(id,user_id,instagram_username,instagram_email,restriction_type,explanation,evidence_key)
          VALUES(?,?,?,?,?,?,?)`).bind(id, user.id, username, email, restriction, explanation, evidenceKey).run();
        return json({ ok: true, id, status: "submitted" }, 201);
      }

      if (url.pathname === "/api/my-data" && request.method === "GET") {
        const user = await requireUser(request, env);
        if (!user) return fail("Please log in first.", 401);
        const [payments, appeals] = await Promise.all([
          env.DB.prepare("SELECT id,kind,amount_kobo,status,created_at FROM payments WHERE user_id=? ORDER BY created_at DESC").bind(user.id).all(),
          env.DB.prepare("SELECT id,instagram_username,restriction_type,status,admin_note,created_at FROM appeals WHERE user_id=? ORDER BY created_at DESC").bind(user.id).all()
        ]);
        return json({ user, payments: payments.results, appeals: appeals.results });
      }

      if (url.pathname.startsWith("/api/owner/")) {
        if (!(await isOwner(request, env))) return fail("Owner access required.", 403);

        if (url.pathname === "/api/owner/overview" && request.method === "GET") {
          const [users, payments, appeals] = await Promise.all([
            env.DB.prepare("SELECT id,phone,created_at,access_granted FROM users ORDER BY created_at DESC LIMIT 200").all(),
            env.DB.prepare(`SELECT p.*,u.phone FROM payments p JOIN users u ON u.id=p.user_id ORDER BY p.created_at DESC LIMIT 200`).all(),
            env.DB.prepare(`SELECT a.*,u.phone FROM appeals a JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT 200`).all()
          ]);
          return json({ users: users.results, payments: payments.results, appeals: appeals.results });
        }

        const receiptMatch = url.pathname.match(/^\/api\/owner\/receipts\/([a-f0-9-]+)$/i);
        if (receiptMatch && request.method === "GET") {
          const row = await env.DB.prepare("SELECT receipt_key FROM payments WHERE id=?").bind(receiptMatch[1]).first();
          if (!row) return fail("Receipt not found.", 404);
          const object = await env.RECEIPTS.get(row.receipt_key);
          if (!object) return fail("Receipt file not found.", 404);
          return new Response(object.body, { headers: { "content-type": object.httpMetadata?.contentType || "application/octet-stream", "cache-control": "no-store" } });
        }

        const paymentMatch = url.pathname.match(/^\/api\/owner\/payments\/([a-f0-9-]+)$/i);
        if (paymentMatch && request.method === "PATCH") {
          const body = await request.json();
          if (!["approved", "rejected"].includes(body.status)) return fail("Invalid payment decision.");
          const payment = await env.DB.prepare("SELECT * FROM payments WHERE id=?").bind(paymentMatch[1]).first();
          if (!payment) return fail("Payment not found.", 404);
          await env.DB.prepare("UPDATE payments SET status=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?").bind(body.status, payment.id).run();
          if (payment.kind === "registration" && body.status === "approved") {
            await env.DB.prepare("UPDATE users SET access_granted=1 WHERE id=?").bind(payment.user_id).run();
          }
          return json({ ok: true });
        }

        const appealMatch = url.pathname.match(/^\/api\/owner\/appeals\/([a-f0-9-]+)$/i);
        if (appealMatch && request.method === "PATCH") {
          const body = await request.json();
          const allowed = ["under_review", "needs_changes", "ready_to_submit", "submitted_to_meta", "closed"];
          if (!allowed.includes(body.status)) return fail("Invalid appeal status.");
          if (["ready_to_submit", "submitted_to_meta"].includes(body.status)) {
            const paid = await env.DB.prepare("SELECT id FROM payments WHERE user_id=(SELECT user_id FROM appeals WHERE id=?) AND kind='service' AND status='approved'").bind(appealMatch[1]).first();
            if (!paid) return fail("Approve the customer's service payment before moving this appeal to final submission.");
          }
          await env.DB.prepare("UPDATE appeals SET status=?,admin_note=?,updated_at=CURRENT_TIMESTAMP WHERE id=?")
            .bind(body.status, String(body.admin_note || "").slice(0, 2000), appealMatch[1]).run();
          return json({ ok: true });
        }
      }

      return fail("Not found.", 404);
    } catch (error) {
      console.error(error);
      return fail(error.message || "Unexpected server error.", 500);
    }
  }
};
